"""Step 4: text analysis (course weeks 5-7)."""
import re
from collections import Counter

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS, TfidfVectorizer

from . import config

# Words that fill pop lyrics but say nothing. TODO: grow this list after looking at counts.
LYRIC_STOP_WORDS = {"oh", "ooh", "yeah", "ah", "na", "la", "hey", "uh", "woah", "whoa",
                    "baby", "gonna", "wanna", "gotta", "like", "just", "got", "don", "ll",
                    "ve", "re", "im", "cause", "let", "know", "da", "mmm", "ya"}
STOP_WORDS = set(ENGLISH_STOP_WORDS) | LYRIC_STOP_WORDS


def clean_lyrics(text: str) -> str:
    """Remove Genius extras: '[Chorus: X]', the 'Lyrics' header, 'Embed' at the end."""
    text = re.sub(r"\[.*?\]", " ", text)
    text = re.sub(r"^.*?Lyrics", "", text, count=1, flags=re.S)   # header line from lyricsgenius
    text = re.sub(r"\d*Embed$", "", text.strip())
    return text.lower()


def tokenize(text: str, remove_stop: bool = True) -> list[str]:
    tokens = re.findall(r"[a-z']+", text.lower())
    tokens = [t.strip("'") for t in tokens if len(t.strip("'")) > 1]
    return [t for t in tokens if t not in STOP_WORDS] if remove_stop else tokens


def unique_lines(text: str) -> str:
    """Keep each line once, so a chorus sung 6 times does not count 6 times."""
    return "\n".join(dict.fromkeys(l.strip() for l in text.splitlines() if l.strip()))


def songs_dataframe(songs: list[dict]) -> pd.DataFrame:
    df = pd.DataFrame(songs)
    df["clean"] = df["lyrics"].fillna("").map(clean_lyrics).map(unique_lines)
    df["tokens"] = df["clean"].map(tokenize)
    return df[df["tokens"].map(len) > 20]          # drop instrumentals / failed downloads


def tfidf_by_group(docs: dict[str, list[str]], top_n: int = 15) -> dict[str, list[tuple]]:
    """docs = {group: tokens}. One document per group -> top TF-IDF words per group."""
    groups = list(docs)
    vec = TfidfVectorizer(analyzer=lambda toks: toks, sublinear_tf=True)
    X = vec.fit_transform([docs[g] for g in groups])
    vocab = np.array(vec.get_feature_names_out())
    out = {}
    for i, g in enumerate(groups):
        row = X[i].toarray().ravel()
        idx = row.argsort()[::-1][:top_n]
        out[g] = list(zip(vocab[idx], row[idx].round(3)))
    return out


def wordcloud_for(word_scores: dict[str, float], path) -> None:
    from wordcloud import WordCloud
    wc = WordCloud(width=800, height=400, background_color="white")
    wc.generate_from_frequencies(word_scores).to_file(str(path))


# ---- LabMT sentiment (Dodds et al. 2011) ----
def load_labmt(path=None) -> dict[str, float]:
    """LabMT word -> happiness (1-9). Works with the paper's Data_Set_S1.txt (3 info lines
    first) and with labMT1.txt from the `labMTsimple` package (pip install labMTsimple)."""
    path = path or config.DATA_RAW / "labmt.txt"
    lines = open(path, encoding="utf-8").read().splitlines()
    start = next(i for i, l in enumerate(lines) if l.lower().startswith("word"))
    header = lines[start].split("\t")
    col = next(i for i, h in enumerate(header) if h.startswith("happ"))
    out = {}
    for l in lines[start + 1:]:
        parts = l.split("\t")
        if len(parts) > col:
            out[parts[0]] = float(parts[col])
    return out


def happiness(tokens: list[str], labmt: dict[str, float], exclude_neutral: float = 1.0) -> float:
    """Average LabMT happiness. Words within +-exclude_neutral of 5 are skipped
    (the 'delta h' trick from the paper) so neutral words don't drown the signal."""
    counts = Counter(t for t in tokens if t in labmt and abs(labmt[t] - 5) >= exclude_neutral)
    total = sum(counts.values())
    return np.nan if total == 0 else sum(labmt[w] * c for w, c in counts.items()) / total


def vader_score(text: str) -> float:
    """Second opinion: VADER compound score (-1 sad ... +1 happy)."""
    from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
    return SentimentIntensityAnalyzer().polarity_scores(text)["compound"]
