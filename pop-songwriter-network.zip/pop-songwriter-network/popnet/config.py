"""All settings in one place. Change things here, not inside the other files."""
import os
from pathlib import Path

# ---- Paths ----
ROOT = Path(__file__).resolve().parent.parent
DATA_RAW = ROOT / "data" / "raw"
DATA_PROCESSED = ROOT / "data" / "processed"
FIGURES = ROOT / "figures"
for _p in (DATA_RAW, DATA_PROCESSED, FIGURES):
    _p.mkdir(parents=True, exist_ok=True)

# ---- APIs ----
GENIUS_TOKEN = os.environ.get("GENIUS_TOKEN", "")
# Wikipedia asks every script to send a User-Agent with a way to contact you.
USER_AGENT = os.environ.get("WIKI_USER_AGENT", "02805-pop-network/0.1 (DTU student course project)")

# ---- Which artists ----
# Wikipedia list pages to pull artist links from.
# TODO: open each page in a browser to check it exists and fits; add more if needed.
ARTIST_LIST_PAGES = [
    "List of dance-pop artists",
]
# Artists you want for sure, even if they are not on the lists above.
SEED_ARTISTS = [
    "Katy Perry", "Taylor Swift", "Jessie J", "Ariana Grande", "Lady Gaga", "Rihanna",
    "Britney Spears", "Kesha", "Dua Lipa", "Selena Gomez", "Demi Lovato", "Miley Cyrus",
    "Ed Sheeran", "Justin Bieber", "Sia", "Ellie Goulding", "Rita Ora", "Charli XCX",
    "Olivia Rodrigo", "Billie Eilish", "Sabrina Carpenter", "The Weeknd", "Bruno Mars",
    "Beyonc\u00e9", "Christina Aguilera", "Pink (singer)", "Kelly Clarkson", "Camila Cabello",
    "Halsey (singer)", "Lizzo", "Doja Cat", "Harry Styles", "Shawn Mendes", "Meghan Trainor",
    "Zara Larsson", "Tove Lo", "Anne-Marie (singer)", "Little Mix", "One Direction",
    "Jason Derulo", "Carly Rae Jepsen", "Avril Lavigne", "Lorde", "Adele", "Sam Smith",
]
MAX_ARTISTS = 400         # start small; raise to 200-400 when everything works

# ---- Songs ----
SONGS_PER_ARTIST = 30     # most popular songs per artist on Genius (for credits)
LYRICS_PER_ARTIST = 15    # lyrics only for the top songs (lyrics download is the slow part)
YEAR_MIN, YEAR_MAX = 2000, 2025
DOWNLOAD_LYRICS = True

# ---- Network ----
MIN_EDGE_WEIGHT = 2       # artist-artist edge only if they share >= this many songwriters
RANDOM_SEED = 42
